from django.urls import path

from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    #Base
    path("", views.inicio, name="inicio"),
    path("b", views.b, name="b"),
    path("c", views.c, name="c"),
    path("e", views.e, name="e"),
    path("d", views.d, name="d")
]