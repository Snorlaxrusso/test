from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, HttpResponseRedirect , JsonResponse
from .models import pdf
from django.urls import reverse
from pathlib import Path

import os

def inicio(request):
    return render(request, "inicio.html")

def b(request):
    if request.method == "POST":
        archivo = request.FILES["imagen"]
        nombre = str(archivo)
        fs = FileSystemStorage()  
        fs.save(nombre, archivo)
    return HttpResponseRedirect(reverse(inicio))

def c(request):
    if request.method == "POST":
        archivo = request.FILES["imagen"]
        pdf(a = archivo).save()
    return HttpResponseRedirect(reverse(inicio))

def d(request):
    if request.method == "POST":
        nombre = request.POST["nombre"]
        fs = FileSystemStorage()
        path = fs.path(nombre)
        fs.delete(path)
    return HttpResponseRedirect(reverse(inicio))

def e(request):
    if request.method == "POST":
        nombre = request.POST["nombre"]
        pdf.objects.get(a = nombre).delete()
        BASE_DIR = Path(__file__).resolve().parent.parent
        os.remove(BASE_DIR / 'media/' / nombre)
    return HttpResponseRedirect(reverse(inicio))