from django.db import models


class pdf(models.Model):
    a = models.FileField()